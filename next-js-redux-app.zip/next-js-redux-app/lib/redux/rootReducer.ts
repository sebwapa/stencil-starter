/* Instruments */
import { counterSlice } from './slices'

export const reducer = {
  counter: counterSlice.reducer,
}
